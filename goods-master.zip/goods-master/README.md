# 购物商城 Android 应用

## 项目简介

这是一个基于 Android Studio 开发的购物商城应用，作为毕业设计项目。应用实现了用户登录、商品浏览和购物车管理等核心功能。

## 功能特性

### 1. 用户登录
- 用户注册功能
- 用户登录验证
- 登录状态持久化
- 退出登录功能

### 2. 商品浏览
- 商品列表展示（网格布局）
- 商品详情查看
- 商品信息包括：名称、价格、描述、库存

### 3. 购物车
- 添加商品到购物车
- 修改商品数量
- 删除购物车商品
- 购物车总价计算
- 结算功能

### 4. 底部导航
- 商品页面
- 购物车页面
- 订单页面（预留）
- 用户页面

## 技术栈

- **开发语言**: Java
- **最低支持版本**: Android 7.0 (API 24)
- **目标版本**: Android 13 (API 33)
- **主要依赖库**:
  - AndroidX AppCompat
  - Material Design Components
  - RecyclerView
  - Glide (图片加载)
  - Gson (JSON解析)

## 项目结构

```
app/
├── src/main/
│   ├── java/com/shoppingmall/app/
│   │   ├── LoginActivity.java          # 登录界面
│   │   ├── MainActivity.java            # 主界面（底部导航）
│   │   ├── ProductDetailActivity.java   # 商品详情
│   │   ├── ProductFragment.java         # 商品列表Fragment
│   │   ├── CartFragment.java            # 购物车Fragment
│   │   ├── OrderFragment.java           # 订单Fragment
│   │   ├── UserFragment.java            # 用户Fragment
│   │   ├── Product.java                 # 商品数据模型
│   │   ├── CartItem.java                # 购物车项数据模型
│   │   ├── CartManager.java             # 购物车管理器（单例）
│   │   ├── ProductAdapter.java          # 商品列表适配器
│   │   └── CartAdapter.java             # 购物车适配器
│   ├── res/
│   │   ├── layout/                      # 布局文件
│   │   ├── values/                      # 资源文件
│   │   └── menu/                        # 菜单文件
│   └── AndroidManifest.xml
└── build.gradle
```

## 安装与运行

1. 使用 Android Studio 打开项目
2. 同步 Gradle 依赖
3. 连接 Android 设备或启动模拟器
4. 点击运行按钮

## 使用说明

1. **首次使用**: 在登录界面输入用户名和密码，点击"注册"按钮
2. **登录**: 使用已注册的用户名和密码登录
3. **浏览商品**: 在商品页面查看商品列表，点击商品查看详情
4. **添加购物车**: 在商品详情页面点击"加入购物车"
5. **管理购物车**: 在购物车页面可以修改数量、删除商品、结算
6. **退出登录**: 在用户页面点击"退出登录"

## 开发说明

本项目采用以下设计模式：
- **单例模式**: CartManager 使用单例模式管理购物车
- **适配器模式**: RecyclerView 使用适配器模式展示列表
- **Fragment模式**: 使用Fragment实现底部导航切换

## 后续扩展

- [ ] 连接后端服务器API
- [ ] 实现订单管理功能
- [ ] 添加商品搜索功能
- [ ] 实现用户信息管理
- [ ] 添加商品图片加载
- [ ] 实现支付功能

## 作者

毕业设计项目

## 许可证

本项目仅用于学习目的

