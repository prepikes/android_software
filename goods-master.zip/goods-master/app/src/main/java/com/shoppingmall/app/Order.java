package com.shoppingmall.app;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Order implements Serializable {
    private int id;
    private List<OrderItem> items;
    private double totalPrice;
    private String status; // 待付款、待发货、待收货、已完成、已取消
    private String createTime;
    private String orderNumber;

    public Order(int id, List<OrderItem> items) {
        this.id = id;
        this.items = new ArrayList<>(items);
        this.totalPrice = calculateTotalPrice();
        this.status = "待付款";
        this.createTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        this.orderNumber = generateOrderNumber();
    }

    private double calculateTotalPrice() {
        double total = 0;
        for (OrderItem item : items) {
            total += item.getTotalPrice();
        }
        return total;
    }

    private String generateOrderNumber() {
        return "ORD" + System.currentTimeMillis();
    }

    public int getId() {
        return id;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateTime() {
        return createTime;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public int getItemCount() {
        int count = 0;
        for (OrderItem item : items) {
            count += item.getQuantity();
        }
        return count;
    }
}

