package com.shoppingmall.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OrderFragment extends Fragment {
    private RecyclerView recyclerView;
    private OrderAdapter adapter;
    private TextView tvEmptyOrders;
    private OrderManager orderManager;
    private List<Order> orders;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_order, container, false);

        recyclerView = view.findViewById(R.id.recycler_view_orders);
        tvEmptyOrders = view.findViewById(R.id.tv_empty_orders);

        orderManager = OrderManager.getInstance(getContext());
        orders = orderManager.getOrders();

        // 设置RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new OrderAdapter(orders, new OrderAdapter.OnOrderClickListener() {
            @Override
            public void onOrderClick(Order order) {
                // 点击订单项，可以跳转到订单详情页面
                Toast.makeText(getContext(), "订单号：" + order.getOrderNumber(), Toast.LENGTH_SHORT).show();
                // TODO: 可以添加订单详情Activity
            }
        });
        recyclerView.setAdapter(adapter);

        checkEmptyOrders();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // 刷新订单列表
        orders = orderManager.getOrders();
        adapter.updateOrders(orders);
        checkEmptyOrders();
    }

    private void checkEmptyOrders() {
        if (orders.isEmpty()) {
            tvEmptyOrders.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmptyOrders.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }
}

