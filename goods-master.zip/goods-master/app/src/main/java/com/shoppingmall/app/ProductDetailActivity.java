package com.shoppingmall.app;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;

public class ProductDetailActivity extends AppCompatActivity {
    private Product product;
    private ImageView ivImage;
    private TextView tvName, tvPrice, tvDescription, tvStock;
    private Button btnAddToCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        product = (Product) getIntent().getSerializableExtra("product");
        if (product == null) {
            finish();
            return;
        }

        ivImage = findViewById(R.id.iv_detail_image);
        tvName = findViewById(R.id.tv_detail_name);
        tvPrice = findViewById(R.id.tv_detail_price);
        tvDescription = findViewById(R.id.tv_detail_description);
        tvStock = findViewById(R.id.tv_detail_stock);
        btnAddToCart = findViewById(R.id.btn_add_to_cart);

        tvName.setText(product.getName());
        tvPrice.setText("¥" + String.format("%.2f", product.getPrice()));
        tvDescription.setText(product.getDescription());
        tvStock.setText("库存：" + product.getStock());

        // 加载商品图片
        if (product.getImageUrl() != null && !product.getImageUrl().isEmpty()) {
            Glide.with(this)
                    .load(product.getImageUrl())
                    .placeholder(R.drawable.ic_launcher_background)
                    .into(ivImage);
        }

        btnAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CartManager.getInstance().addToCart(product, 1);
                Toast.makeText(ProductDetailActivity.this, "已添加到购物车", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

