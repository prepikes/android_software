package com.shoppingmall.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class CartFragment extends Fragment {
    private RecyclerView recyclerView;
    private CartAdapter adapter;
    private TextView tvTotalPrice, tvEmptyCart;
    private Button btnCheckout;
    private List<CartItem> cartItems;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cart, container, false);

        recyclerView = view.findViewById(R.id.recycler_view_cart);
        tvTotalPrice = view.findViewById(R.id.tv_total_price);
        tvEmptyCart = view.findViewById(R.id.tv_empty_cart);
        btnCheckout = view.findViewById(R.id.btn_checkout);

        cartItems = CartManager.getInstance().getCartItems();

        // 设置RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new CartAdapter(cartItems, new CartAdapter.OnCartChangeListener() {
            @Override
            public void onCartChanged() {
                updateTotalPrice();
                checkEmptyCart();
            }
        });
        recyclerView.setAdapter(adapter);

        btnCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cartItems.isEmpty()) {
                    Toast.makeText(getContext(), "购物车为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                // 创建订单
                OrderManager.getInstance(getContext()).createOrder(new ArrayList<>(cartItems));
                // 清空购物车
                CartManager.getInstance().clearCart();
                adapter.notifyDataSetChanged();
                updateTotalPrice();
                checkEmptyCart();
                Toast.makeText(getContext(), "订单创建成功！", Toast.LENGTH_SHORT).show();
            }
        });

        updateTotalPrice();
        checkEmptyCart();

        return view;
    }

    private void updateTotalPrice() {
        double total = CartManager.getInstance().getTotalPrice();
        tvTotalPrice.setText("总价：¥" + String.format("%.2f", total));
    }

    private void checkEmptyCart() {
        if (cartItems.isEmpty()) {
            tvEmptyCart.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
            btnCheckout.setEnabled(false);
        } else {
            tvEmptyCart.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            btnCheckout.setEnabled(true);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        adapter.notifyDataSetChanged();
        updateTotalPrice();
        checkEmptyCart();
    }
}

