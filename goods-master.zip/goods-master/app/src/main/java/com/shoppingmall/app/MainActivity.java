package com.shoppingmall.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNavigation;
    private Fragment productFragment, cartFragment, orderFragment, userFragment;
    private TextView tvCartBadge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigation = findViewById(R.id.bottom_navigation);

        // 初始化Fragment
        productFragment = new ProductFragment();
        cartFragment = new CartFragment();
        orderFragment = new OrderFragment();
        userFragment = new UserFragment();

        // 默认显示商品页面
        loadFragment(productFragment);

        bottomNavigation.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_product) {
                    loadFragment(productFragment);
                    return true;
                } else if (itemId == R.id.nav_cart) {
                    loadFragment(cartFragment);
                    return true;
                } else if (itemId == R.id.nav_order) {
                    loadFragment(orderFragment);
                    return true;
                } else if (itemId == R.id.nav_user) {
                    loadFragment(userFragment);
                    return true;
                }
                return false;
            }
        });

        // 检查登录状态
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        if (!sharedPreferences.getBoolean("isLoggedIn", false)) {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
    }

    private void loadFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 更新购物车徽章
        updateCartBadge();
    }

    private void updateCartBadge() {
        int cartCount = CartManager.getInstance().getCartItemCount();
        // 这里可以更新底部导航栏的徽章显示
    }
}

