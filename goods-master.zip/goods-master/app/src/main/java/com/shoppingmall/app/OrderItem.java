package com.shoppingmall.app;

import java.io.Serializable;

public class OrderItem implements Serializable {
    private Product product;
    private int quantity;
    private double price; // 下单时的价格

    public OrderItem(Product product, int quantity, double price) {
        this.product = product;
        this.quantity = quantity;
        this.price = price;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }

    public double getTotalPrice() {
        return price * quantity;
    }
}

