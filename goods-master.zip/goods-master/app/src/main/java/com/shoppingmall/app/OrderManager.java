package com.shoppingmall.app;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class OrderManager {
    private static OrderManager instance;
    private List<Order> orders;
    private static final String PREFS_NAME = "OrderPrefs";
    private static final String KEY_ORDERS = "orders";
    private static final String KEY_ORDER_ID = "order_id_counter";
    private Context context;
    private Gson gson;

    private OrderManager(Context context) {
        this.context = context.getApplicationContext();
        this.gson = new Gson();
        loadOrders();
    }

    public static OrderManager getInstance(Context context) {
        if (instance == null) {
            instance = new OrderManager(context);
        }
        return instance;
    }

    public void createOrder(List<CartItem> cartItems) {
        if (cartItems == null || cartItems.isEmpty()) {
            return;
        }

        // 将 CartItem 转换为 OrderItem
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem cartItem : cartItems) {
            Product product = cartItem.getProduct();
            OrderItem orderItem = new OrderItem(
                product,
                cartItem.getQuantity(),
                product.getPrice() // 保存下单时的价格
            );
            orderItems.add(orderItem);
        }

        // 生成订单ID
        int orderId = getNextOrderId();

        // 创建订单
        Order order = new Order(orderId, orderItems);
        orders.add(0, order); // 添加到列表开头，最新的订单在前

        saveOrders();
    }

    private int getNextOrderId() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int currentId = prefs.getInt(KEY_ORDER_ID, 0);
        int nextId = currentId + 1;
        prefs.edit().putInt(KEY_ORDER_ID, nextId).apply();
        return nextId;
    }

    public List<Order> getOrders() {
        return new ArrayList<>(orders);
    }

    public Order getOrderById(int orderId) {
        for (Order order : orders) {
            if (order.getId() == orderId) {
                return order;
            }
        }
        return null;
    }

    public void updateOrderStatus(int orderId, String status) {
        Order order = getOrderById(orderId);
        if (order != null) {
            order.setStatus(status);
            saveOrders();
        }
    }

    private void loadOrders() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String ordersJson = prefs.getString(KEY_ORDERS, null);

        if (ordersJson != null) {
            Type type = new TypeToken<List<Order>>() {}.getType();
            orders = gson.fromJson(ordersJson, type);
        } else {
            orders = new ArrayList<>();
        }
    }

    private void saveOrders() {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String ordersJson = gson.toJson(orders);
        prefs.edit().putString(KEY_ORDERS, ordersJson).apply();
    }
}

