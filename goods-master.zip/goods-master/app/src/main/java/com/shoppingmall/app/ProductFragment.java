package com.shoppingmall.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ProductFragment extends Fragment {
    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private List<Product> productList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_product, container, false);
        recyclerView = view.findViewById(R.id.recycler_view_products);

        // 初始化商品数据
        initProducts();

        // 设置RecyclerView
        GridLayoutManager layoutManager = new GridLayoutManager(getContext(), 2);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new ProductAdapter(productList, new ProductAdapter.OnProductClickListener() {
            @Override
            public void onProductClick(Product product) {
                Intent intent = new Intent(getContext(), ProductDetailActivity.class);
                intent.putExtra("product", product);
                startActivity(intent);
            }
        });
        recyclerView.setAdapter(adapter);

        return view;
    }

    private void initProducts() {
        productList = new ArrayList<>();
        // 使用 drawable 资源的 URI 格式
        String imageUri = "android.resource://" + getContext().getPackageName() + "/drawable/good";
        // 添加示例商品数据
        productList.add(new Product(1, "智能手机", "高性能智能手机，6.7英寸屏幕", 2999.00, imageUri, 100));
        productList.add(new Product(2, "笔记本电脑", "轻薄便携，高性能处理器", 5999.00, imageUri, 50));
        productList.add(new Product(3, "无线耳机", "降噪蓝牙耳机，长续航", 299.00, imageUri, 200));
        productList.add(new Product(4, "智能手表", "健康监测，运动追踪", 1299.00, imageUri, 80));
        productList.add(new Product(5, "平板电脑", "10.2英寸，适合学习和娱乐", 2499.00, imageUri, 60));
        productList.add(new Product(6, "机械键盘", "RGB背光，青轴手感", 399.00, imageUri, 150));
        productList.add(new Product(7, "游戏鼠标", "高精度传感器，人体工学设计", 199.00, imageUri, 180));
        productList.add(new Product(8, "显示器", "27英寸4K显示器，色彩精准", 1999.00, imageUri, 40));
    }
}

